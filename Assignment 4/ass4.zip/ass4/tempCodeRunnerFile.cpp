#include <iostream>
using namespace std;

int main(){
    int arr[10];
    arr = {0};
    cout<<arr[4];
}