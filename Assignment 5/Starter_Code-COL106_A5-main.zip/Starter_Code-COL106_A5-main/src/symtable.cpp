/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"

//Write your code below this line

SymbolTable::SymbolTable(){

}

void SymbolTable::insert(string k){

}

void SymbolTable::remove(string k){

}

int SymbolTable::search(string k){

}

void SymbolTable::assign_address(string k,int idx){

}

int SymbolTable::get_size(){

}

SymNode* SymbolTable::get_root(){

}

SymbolTable::~SymbolTable(){

}